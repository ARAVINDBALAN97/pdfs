-----Category table

create table Tbl_Category(Category_id  varchar(20) constraint pk_Tbl_Category_Category_id Primary key,
Category_Name varchar(20),
)

-----Skill table

Create Table Tbl_Skill(Skill_id varchar(10) constraint pk_Tbl_skill_Skill_id Primary key,
Category_id varchar(10) constraint fk_Tbl_skill_Category_id Foreign key References Tbl_Category(Category_id)  on delete cascade on update cascade,
Skill_Name varchar(25))

-----Score description

create table Tbl_Score_Description(Score_id tinyint,Score_Description varchar(25),constraint pk_Tbl_Score_Description_Score_id Primary key(Score_id));


-----Employee Score
create table Tbl_Employee_Score(
Employee_id varchar(10) ,--constraint fk_tbl_Employee_Score_EmpID Foreign key References ,
Category_id varchar(10) constraint fk_tbl_Employee_Score_Category_id Foreign key References Tbl_Category(Category_id),
Skill_id varchar(10) constraint fk_tbl_Employee_Score_Skill_id Foreign key References Tbl_Skill(Skill_id),
Score_id  tinyint constraint fk_tbl_Employee_Score_Score_id Foreign key References Tbl_Score_Description(Score_id),
) ;


