-----Category table

create table Tbl_Category(Category_id  varchar(20),Category_Name varchar(20),
constraint pk_Tbl_Category_Category_id primary key(Category_id) )

-----Skill table

Create Table Tbl_Skill(Skill_id varchar(10),Category_id varchar(10),Skill_Name varchar(25),
constraint pk_Tbl_skill_Skill_id Primary key(Skill_id),
constraint fk_Tbl_skill_Category_id Foreign key(Category_id) References Tbl_Category(Category_id)on delete cascade on update cascade
);

-----Score description

create table Tbl_Score_Description(Score_id tinyint,Score_Description varchar(25),constraint pk_Tbl_Score_Description_Score_id Primary key(Score_id));


-----Employee Score
create table Tbl_Employee_Score(Employee_id varchar(10),Category_id varchar(10),Skill_id varchar(10),Score_id  tinyint ,
constraint fk_tbl_Employee_Score_EmpID Foreign key(EmpID) References Employee_new1(EmpID),
constraint fk_tbl_Employee_Score_Category_id Foreign key(Category_id) References Tbl_Category(Category_id),
constraint fk_tbl_Employee_Score_Skill_id Foreign key(Skill_id) References Tbl_Skill(Skill_id),
constraint fk_tbl_Employee_Score_Score_id Foreign key(Score_id) References Tbl_Score_Description(Score_id)
) ;