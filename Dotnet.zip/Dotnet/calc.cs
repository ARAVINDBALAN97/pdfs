using System;
class calc
{
void addone( int var,out int n1,out int n2,out int n3)
{
    n1=++var;
    n2=var+2;
    n3=var+3;
  
}
public static void Main()
{
  calc c=new calc();
  int outno,outno1,outno2;
  int number =6;
  c.addone(number,out outno,out outno1,out outno2);
  Console.WriteLine(number); 
  Console.WriteLine(outno); 
  Console.WriteLine(outno1); 
  Console.WriteLine(outno2); 
}
}         
 