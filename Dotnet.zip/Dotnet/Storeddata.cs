﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
using System.Configuration;
using System.Data;

namespace Storeddata
{
    class Program
    {
        
        static void Main(string[] args)
        {
            String str,name,address;
            int age,id;
            try {
                str ="Data Source=172.17.1.160;Initial Catalog=db_dharman;Integrated Security=True";
            
                   SqlConnection con = new SqlConnection(str);
                   con.Open();
                   Console.WriteLine("database connected");
                   Console.WriteLine("enter your id");
                   id=Int32.Parse(Console.ReadLine());
                   Console.WriteLine("enter your name");
                   name=  Console.ReadLine();
                   Console.WriteLine("enter your address");
                   address = Console.ReadLine();
                   Console.WriteLine("enter your age");
                   age = Int32.Parse(Console.ReadLine());
                   string query = "insert into userdetail values('" + id + "','" + name + "','" + address + "','" + age + "')";
                   SqlCommand cmd = new SqlCommand(query, con);
                   cmd.ExecuteNonQuery();
                
                   Console.WriteLine("data saved");
                   
                   string q = "select * from userdetail";
                   SqlCommand cmd1 = new SqlCommand(q, con);
                   SqlDataReader dr= cmd1.ExecuteReader();
                 while(dr.Read())
                {
                    Console.WriteLine("name:"+dr.GetValue(1)+dr.GetValue(0).ToString());
                }
                con.Close();
                Console.ReadLine();
            }
            catch(Exception ae)
            {
                throw ae;
            }
         
        }
    }
}
